<?php namespace App\SupportedApps\Dashdot;

class Dashdot extends \App\SupportedApps
{
}
