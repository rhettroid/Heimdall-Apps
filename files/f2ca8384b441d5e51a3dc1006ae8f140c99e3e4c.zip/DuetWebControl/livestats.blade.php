<ul class="livestats">
    <li>
        <span class="title">Status</span>
        <strong>{!! $printer_status !!}</strong>
    </li>
    <li>
        <span class="title">Progress</span>
        <strong>{!! $job_progress !!}</strong>
    </li>
</ul>
