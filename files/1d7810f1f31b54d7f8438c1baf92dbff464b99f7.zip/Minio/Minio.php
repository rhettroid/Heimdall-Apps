<?php namespace App\SupportedApps\Minio;

class Minio extends \App\SupportedApps
{
}
