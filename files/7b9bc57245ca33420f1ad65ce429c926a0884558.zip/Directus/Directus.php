<?php namespace App\SupportedApps\Directus;

class Directus extends \App\SupportedApps
{
}
