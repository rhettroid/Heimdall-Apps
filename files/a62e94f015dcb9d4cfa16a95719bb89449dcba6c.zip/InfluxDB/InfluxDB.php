<?php namespace App\SupportedApps\InfluxDB;

class InfluxDB extends \App\SupportedApps
{
}
