<ul class="livestats">
    <li>
        <span class="title">Traces</span>
        <strong>{!! $traces !!}</strong>
    </li>
    <li>
        <span class="title">Duration</span>
        <strong>{!! $avg_duration !!} ms</strong>
    </li>
</ul>
