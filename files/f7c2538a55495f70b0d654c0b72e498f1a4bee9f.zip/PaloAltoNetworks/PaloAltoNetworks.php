<?php namespace App\SupportedApps\PaloAltoNetworks;

class PaloAltoNetworks extends \App\SupportedApps
{
}
