<?php namespace App\SupportedApps\Confluence;

class Confluence extends \App\SupportedApps
{
}
