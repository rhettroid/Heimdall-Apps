<?php namespace App\SupportedApps\OpenSprinkler;

class OpenSprinkler extends \App\SupportedApps
{
}
