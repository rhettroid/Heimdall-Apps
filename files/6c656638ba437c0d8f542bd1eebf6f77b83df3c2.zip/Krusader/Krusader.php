<?php namespace App\SupportedApps\Krusader;

class Krusader extends \App\SupportedApps
{
}
