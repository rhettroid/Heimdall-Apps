<ul class="livestats">
    <li><span class="title">RUN: {{ $running_count }}</span><strong>{!! $download_rate !!}</strong></li>
    <li><span class="title">DONE: {{ $stopped_count }}</span><strong>{!! $upload_rate !!}</strong></li>
</ul>
