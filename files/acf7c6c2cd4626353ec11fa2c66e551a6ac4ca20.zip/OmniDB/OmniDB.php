<?php namespace App\SupportedApps\OmniDB;

class OmniDB extends \App\SupportedApps
{
}
