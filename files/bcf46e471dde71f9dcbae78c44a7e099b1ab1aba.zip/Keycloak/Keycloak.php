<?php namespace App\SupportedApps\Keycloak;

class Keycloak extends \App\SupportedApps
{
}
