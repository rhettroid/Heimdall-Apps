<?php namespace App\SupportedApps\JDownloader;

class JDownloader extends \App\SupportedApps
{
}
